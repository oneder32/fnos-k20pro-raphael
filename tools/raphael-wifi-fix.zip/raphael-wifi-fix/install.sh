#!/bin/sh
echo "====================================================================="
 echo "raphael (Redmi K20 Pro, SM8150) 无线模块安装脚本 by半杯苏打"
 echo "====================================================================="
# 用法: sudo sh install.sh
set -e

KVER=$(uname -r)
echo "== 当前内核: $KVER =="

# 1) 定位模块目录
MODROOT=""
for R in /usr/lib/modules /lib/modules; do
  if [ -d "$R/$KVER" ]; then MODROOT="$R/$KVER"; break; fi
done
if [ -z "$MODROOT" ]; then
  echo "!! 找不到模块目录 (uname -r = $KVER)"
  ls -d /usr/lib/modules/* /lib/modules/* 2>/dev/null || true
  exit 1
fi
echo "== 模块目录: $MODROOT =="

# 2) 安装内核模块到标准路径
D="$MODROOT/kernel"
mkdir -p "$D/drivers/net/wireless/ath/ath10k" \
         "$D/net/wireless" "$D/net/mac80211" "$D/net/rfkill" \
         "$D/net/bluetooth" "$D/drivers/bluetooth"

cp -v modules/ath.ko          "$D/drivers/net/wireless/ath/"
cp -v modules/ath10k_core.ko  "$D/drivers/net/wireless/ath/ath10k/"
cp -v modules/ath10k_snoc.ko  "$D/drivers/net/wireless/ath/ath10k/"
cp -v modules/cfg80211.ko     "$D/net/wireless/"
cp -v modules/mac80211.ko     "$D/net/mac80211/"
cp -v modules/rfkill.ko       "$D/net/rfkill/"
cp -v modules/bluetooth.ko    "$D/net/bluetooth/"
cp -v modules/btqca.ko        "$D/drivers/bluetooth/"
cp -v modules/hci_uart.ko     "$D/drivers/bluetooth/"

# 3) 重建依赖与别名 (修复 modules.alias 里下划线/连字符不匹配的问题)
echo "== 重建模块依赖 depmod -a =="
if command -v depmod >/dev/null 2>&1; then
  depmod -a
else
  echo "!! 无 depmod，跳过（若 modprobe 失败需手工 insmod）"
fi

# 4) 加载无线驱动
echo "== 加载 ath10k_snoc (WiFi) =="
if command -v modprobe >/dev/null 2>&1; then
  modprobe ath10k_snoc || echo "!! ath10k_snoc 加载失败"
  modprobe hci_uart   || echo "!! hci_uart 加载失败"
else
  # 手工按依赖顺序加载
  for m in rfkill cfg80211 mac80211 ath ath10k_core ath10k_snoc; do
    insmod "$MODROOT/kernel/$(grep -E "^kernel/.*/$m.ko" "$MODROOT/modules.dep" 2>/dev/null | head -1)" 2>/dev/null \
      || insmod "$D/$(find "$D" -name "$m.ko" | head -1 | sed "s|$D/||")" 2>/dev/null \
      || echo "!! 无法加载 $m"
  done
  for m in bluetooth btqca hci_uart; do
    insmod "$D/$(find "$D" -name "$m.ko" | head -1 | sed "s|$D/||")" 2>/dev/null || echo "!! 无法加载 $m"
  done
fi

# 5) 验证
echo ""
echo "== 结果 =="
ip link 2>/dev/null | grep -E "wlan|hci" || echo "(ip link 未显示 wlan/hci)"
echo "== dmesg 中 ath10k/wcn 相关 =="
dmesg 2>/dev/null | grep -iE "ath10k|wcn3990|wcn" | tail -20 || echo "(dmesg 无输出，可能需要 root)"
echo ""
echo "完成。若 wlan0 仍不出现，检查固件: ls /lib/firmware/ath10k/WCN3990/hw1.0/"
